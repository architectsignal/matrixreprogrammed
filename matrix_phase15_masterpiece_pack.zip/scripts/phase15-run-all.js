const { spawnSync } = require('child_process');
const path = require('path');
const root = process.cwd();

const steps = [
  'scripts/build-public-record-entities.js',
  'scripts/build-system-fusion-core.js',
  'scripts/build-outcome-briefings.js',
  'scripts/build-daily-brain-brief.js',
  'scripts/build-free-ask-matrix-search.js',
  'scripts/build-search-v2-final-guard.js',
  'scripts/public-record-entities-test.js',
  'scripts/system-fusion-core-test.js',
  'scripts/free-ask-matrix-search-test.js'
];

for (const step of steps) {
  const result = spawnSync(process.execPath, [path.join(root, step)], { cwd: root, encoding: 'utf8', stdio: 'inherit' });
  if (result.status !== 0) {
    console.error(`PHASE 15 MASTERPIECE RUN FAILED AT ${step}`);
    process.exit(result.status || 1);
  }
}
console.log('PHASE 15 MASTERPIECE RUN PASSED');
