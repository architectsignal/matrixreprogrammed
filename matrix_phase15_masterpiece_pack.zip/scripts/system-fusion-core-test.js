const fs = require('fs');
const path = require('path');
const root = process.cwd();
const issues = [];
function file(name) { return path.join(root, name); }
function exists(name) { return fs.existsSync(file(name)); }
function read(name) { return fs.readFileSync(file(name), 'utf8'); }
function needFile(name) { if (!exists(name)) issues.push(`missing ${name}`); }
function needText(name, text) { if (exists(name) && !read(name).includes(text)) issues.push(`${name} missing ${text}`); }

for (const name of ['data/system-fusion-core.json','data/matrix-nervous-system.json','data/clock-signal-feed.json','system-fusion-core.html']) needFile(name);
needText('system-fusion-core.html', 'SYSTEM FUSION CORE.');
needText('system-fusion-core.html', 'Clock Pressure Inputs');
needText('system-fusion-core.html', 'Missing Records Queue');
if (exists('data/system-fusion-core.json')) {
  const data = JSON.parse(read('data/system-fusion-core.json'));
  if (!data.counts) issues.push('fusion core missing counts');
  if (!Array.isArray(data.prioritySignals)) issues.push('fusion core missing prioritySignals');
  if (!Array.isArray(data.clockPressureInputs)) issues.push('fusion core missing clockPressureInputs');
  if (!Array.isArray(data.missingRecordQueue)) issues.push('fusion core missing missingRecordQueue');
}
if (issues.length) {
  console.error('SYSTEM FUSION CORE TEST FAILED');
  for (const issue of issues) console.error(`- ${issue}`);
  process.exit(1);
}
console.log('SYSTEM FUSION CORE TEST PASSED');
