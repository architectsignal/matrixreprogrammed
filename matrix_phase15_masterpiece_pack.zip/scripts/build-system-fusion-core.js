const fs = require('fs');
const path = require('path');

const root = process.cwd();
const dataDir = path.join(root, 'data');
const downloadsDir = path.join(root, 'downloads');
fs.mkdirSync(dataDir, { recursive: true });
fs.mkdirSync(downloadsDir, { recursive: true });

const updated = new Date().toISOString();
const version = 'PHASE-15-SYSTEM-FUSION-CORE';

const file = name => path.join(root, name);
const exists = name => fs.existsSync(file(name));
const read = name => exists(name) ? fs.readFileSync(file(name), 'utf8') : '';
const write = (name, value) => fs.writeFileSync(file(name), value);
function readJson(name, fallback) { try { const text = read(name); return text ? JSON.parse(text) : fallback; } catch { return fallback; } }
function esc(value = '') { return String(value ?? '').replace(/[&<>"']/g, c => ({ '&':'&amp;', '<':'&lt;', '>':'&gt;', '"':'&quot;', "'":'&#39;' }[c])); }
function arr(value) { return Array.isArray(value) ? value.filter(Boolean) : (value ? [value] : []); }
function clean(value = '') { return String(value ?? '').replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ').trim(); }
function layerFor(text = '') {
  const h = String(text || '').toLowerCase();
  const checks = [
    ['money', ['money','gold','reserve','bank','payment','cbdc','debt','finance']],
    ['identity', ['identity','biometric','wallet','access','login','border','travel']],
    ['information', ['media','platform','search','narrative','source','document','brief']],
    ['security', ['security','war','intelligence','cyber','emergency','surveillance']],
    ['institutions', ['billionaire','foundation','company','contract','lobby','policy','agency']],
    ['disclosure', ['epstein','redaction','withheld','court','file','record','archive']],
    ['review', ['speculation','claim','metadata','counter-source','hypothesis']]
  ];
  return (checks.find(([, terms]) => terms.some(t => h.includes(t))) || ['general'])[0];
}

const feeds = {
  control: readJson('data/control-structure-core.json', { layers: [] }),
  outcomes: readJson('data/outcome-briefings.json', { briefings: [] }),
  daily: readJson('data/daily-brain-brief.json', {}),
  signals: readJson('data/probability-signal-feed-004.json', { signals: [] }),
  snapshot: readJson('data/probability-snapshot.json', { scenarios: [] }),
  clocks: readJson('data/global-risk-clocks.json', { clocks: [] }),
  liveIntel: readJson('downloads/live-intel-latest.json', readJson('data/live-intel.json', { items: [] })),
  forum: readJson('downloads/forum-posts.json', { posts: [] }),
  entities: readJson('data/entities.json', { entities: [] }),
  entityUpdates: readJson('data/entity-updates.json', { highLeverage: [], missingRecordQueue: [] })
};

const prioritySignals = [];

for (const item of arr(feeds.liveIntel.items).slice(0, 24)) {
  prioritySignals.push({
    id: `live-${prioritySignals.length + 1}`,
    title: clean(item.title || item.summary || 'Live intel item'),
    sourceFeed: 'live-intel',
    layer: layerFor([item.lane, item.laneTitle, item.summary, item.whyItMatters].join(' ')),
    route: item.url || item.evidenceRoute || 'live-intel.html',
    evidence: item.evidenceLevel || 'source-linked',
    action: item.nextAction || item.whyItMatters || 'Follow the public source route.',
    clockImpact: 1
  });
}

for (const signal of arr(feeds.signals.signals).slice(0, 24)) {
  prioritySignals.push({
    id: signal.signalId || `signal-${prioritySignals.length + 1}`,
    title: clean(signal.title || 'Probability signal'),
    sourceFeed: 'probability-signal-feed',
    layer: layerFor([signal.lane, signal.title, signal.whyItMatters].join(' ')),
    route: signal.route || 'probability-snapshot.html',
    evidence: signal.sourceStatus || 'signal',
    action: signal.whyItMatters || 'Watch for probability movement.',
    clockImpact: Number(signal.weight || 1)
  });
}

for (const entity of arr(feeds.entities.entities).slice(0, 40)) {
  if (arr(entity.control_layers).length < 3 && arr(entity.known_records).length < 4) continue;
  prioritySignals.push({
    id: `entity-${entity.id}`,
    title: entity.name,
    sourceFeed: 'entity-engine',
    layer: arr(entity.control_layers)[0] || 'institutions',
    route: `entity.html?id=${encodeURIComponent(entity.id)}`,
    evidence: entity.evidence_grade || 'documented',
    action: arr(entity.missing_records)[0] || 'Attach public records and relationship routes.',
    clockImpact: arr(entity.control_layers).length
  });
}

const clockPressureInputs = arr(feeds.clocks.clocks).map(clock => {
  const hay = [clock.title, clock.signals, clock.status, clock.nextRoute].join(' ');
  const layer = layerFor(hay);
  const linkedSignals = prioritySignals.filter(s => s.layer === layer).slice(0, 8);
  return {
    slug: clock.slug,
    title: clock.title,
    score: Number(clock.score || 0),
    status: clock.status,
    route: clock.nextRoute || 'timers.html',
    layer,
    linkedSignalCount: linkedSignals.length,
    linkedSignals,
    homepageEligible: clock.homepageEligible === true
  };
});

const missingRecordQueue = [
  ...arr(feeds.entityUpdates.missingRecordQueue).map(x => ({ source: 'entity-engine', section: x.entityName, record: x.record, route: x.route || 'power-entities.html' })),
  ...arr(feeds.outcomes.briefings).flatMap(b => arr(b.records || b.recordsNeeded).map(record => ({ source: 'outcome-briefing', section: b.section, record, route: arr(b.pages)[0] || 'evidence-vault.html' }))),
  ...prioritySignals.filter(s => s.action).map(s => ({ source: s.sourceFeed, section: s.layer, record: s.action, route: s.route }))
].slice(0, 180);

const nervousSystem = {
  updated,
  version,
  title: 'System Fusion Core',
  purpose: 'Fuse clocks, live-intel drops, public-record entities, forum exports, probability signals, outcome briefings and the daily brain into one nervous system.',
  boundary: 'This is a routing and evidence-separation layer. It does not turn a signal into proof.',
  counts: {
    controlLayers: arr(feeds.control.layers).length,
    outcomeBriefs: arr(feeds.outcomes.briefings).length,
    dailyBrainSignals: arr(feeds.daily.topSignals).length,
    probabilitySignals: arr(feeds.signals.signals).length,
    scenarios: arr(feeds.snapshot.scenarios).length,
    clocks: arr(feeds.clocks.clocks).length,
    liveIntelItems: arr(feeds.liveIntel.items).length,
    forumPosts: arr(feeds.forum.posts).length,
    entities: arr(feeds.entities.entities).length,
    prioritySignals: prioritySignals.length,
    missingRecordPrompts: missingRecordQueue.length
  },
  prioritySignals,
  clockPressureInputs,
  highLeverageEntities: arr(feeds.entityUpdates.highLeverage).slice(0, 30),
  missingRecordQueue,
  routesToRebuild: ['daily-brain-brief.html','search.html','timers.html','power-entities.html','live-intel.html','evidence-vault.html','control-structure.html'],
  nextAction: 'Rebuild entities, fusion core, daily brain, Search V2, then tests. This keeps every page feeding the same system.'
};

write('data/system-fusion-core.json', JSON.stringify(nervousSystem, null, 2));
write('data/matrix-nervous-system.json', JSON.stringify(nervousSystem, null, 2));
write('data/clock-signal-feed.json', JSON.stringify({ updated, version, clockPressureInputs }, null, 2));
write('downloads/system-fusion-core.md', [
  '# System Fusion Core',
  '',
  `Updated: ${updated}`,
  '',
  nervousSystem.boundary,
  '',
  '## Counts',
  ...Object.entries(nervousSystem.counts).map(([k, v]) => `- ${k}: ${v}`),
  '',
  '## Priority Signals',
  ...prioritySignals.slice(0, 50).map(s => `- ${s.layer}: ${s.title} -> ${s.route}`),
  '',
  '## Clock Inputs',
  ...clockPressureInputs.map(c => `- ${c.title}: ${c.score}% / ${c.linkedSignalCount} linked signal(s)`),
  '',
  '## Missing Records',
  ...missingRecordQueue.slice(0, 80).map(x => `- ${x.section}: ${x.record}`),
  ''
].join('\n'));

function patch(fileName) {
  if (!exists(fileName)) return;
  let html = read(fileName);
  if (html.includes('id="system-fusion-core-route"')) return;
  const block = `<section id="system-fusion-core-route" class="section wrap"><h2>System Fusion Core</h2><p class="lead">The clocks, live intel drops, public-record entities, forum signals, probability feeds and Daily Brain now feed one shared nervous system.</p><div class="cta-row"><a class="btn" href="system-fusion-core.html">Open Fusion Core</a><a class="btn alt" href="data/system-fusion-core.json">Fusion JSON</a><a class="btn alt" href="data/clock-signal-feed.json">Clock Inputs</a></div></section>`;
  html = html.includes('</main>') ? html.replace('</main>', `${block}</main>`) : `${html}\n${block}`;
  write(fileName, html);
}
['index.html','control-structure.html','matrix-brain.html','daily-brain-brief.html','live-intel.html','timers.html','evidence-vault.html','power-entities.html','search.html'].forEach(patch);

function card(title, body, route) { return `<article class="card redline"><h3>${esc(title)}</h3><p>${esc(body)}</p><a class="btn alt" href="${esc(route || '#')}">Open Route</a></article>`; }
const html = `<!DOCTYPE html><html lang="en"><head><meta charset="UTF-8"/><meta name="viewport" content="width=device-width, initial-scale=1.0"/><title>System Fusion Core | Matrix Reprogrammed</title><meta name="description" content="Matrix Reprogrammed fusion core connecting clocks, live intelligence, public-record entities, forum signals, probability feeds and the Daily Brain."/><link rel="stylesheet" href="styles.css"/><link rel="stylesheet" href="fixes.css"/></head><body><canvas id="matrix"></canvas><div class="signal-face"></div><div class="veil"></div><div class="page"><header class="wrap topbar"><a class="brand" href="index.html"><img src="sigil.png" alt="Matrix Reprogrammed sigil"/> MATRIX REPROGRAMMED</a><nav class="nav"><a href="control-structure.html">Control Map</a><a href="power-entities.html">Entities</a><a href="timers.html">Clocks</a><a href="live-intel.html">Live Intel</a><a href="daily-brain-brief.html">Brain</a><a href="search.html">Search</a></nav></header><main><section class="hero wrap"><div class="eyebrow">${version}</div><h1>SYSTEM FUSION CORE.</h1><p class="lead">Everything feeds the machine: clocks, intel drops, public-record entities, reader/forum signals, probability movements, missing records and the Daily Brain.</p><div class="cta-row"><a class="btn" href="data/system-fusion-core.json">Open JSON</a><a class="btn alt" href="data/clock-signal-feed.json">Clock Inputs</a><a class="btn alt" href="power-entities.html">Entity Engine</a></div></section><section class="section wrap split"><div class="terminal">SYSTEM FUSION CORE\n&gt; Updated: ${esc(updated)}\n&gt; Priority signals: ${prioritySignals.length}\n&gt; Clock inputs: ${clockPressureInputs.length}\n&gt; Entities: ${nervousSystem.counts.entities}\n&gt; Missing-record prompts: ${missingRecordQueue.length}\n&gt; Boundary: signal is not proof</div><aside class="card redline"><h2>What Changed</h2><p>This layer turns the site from connected pages into a single operating system. Updates now become clock inputs, entity updates, search routes, missing-record prompts and brain brief material.</p></aside></section><section class="section wrap"><h2>Priority Signals</h2><div class="grid">${prioritySignals.slice(0, 24).map(s => card(`${s.layer}: ${s.title}`, `${s.evidence} — ${s.action}`, s.route)).join('')}</div></section><section class="section wrap"><h2>Clock Pressure Inputs</h2><div class="grid">${clockPressureInputs.map(c => card(`${c.title} — ${c.score}%`, `${c.linkedSignalCount} linked signal(s). Homepage eligible: ${c.homepageEligible ? 'yes' : 'no'}.`, c.route)).join('')}</div></section><section class="section wrap"><h2>Missing Records Queue</h2><div class="grid">${missingRecordQueue.slice(0, 36).map(x => card(x.section || x.source, x.record, x.route)).join('')}</div></section></main><footer class="footer wrap"><p><strong>MATRIX REPROGRAMMED</strong> — living brain architecture, source first.</p></footer></div><script src="matrix.js"></script><script src="living-pulse.js"></script></body></html>`;
write('system-fusion-core.html', html);

console.log(`System Fusion Core built: ${prioritySignals.length} priority signals, ${clockPressureInputs.length} clock inputs, ${missingRecordQueue.length} missing-record prompts.`);
