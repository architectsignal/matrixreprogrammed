const fs = require('fs');
const path = require('path');
const { spawnSync } = require('child_process');

const root = process.cwd();
const issues = [];
const required = ['SEARCH V2', '/search-index.json', 'layerMap', 'control-structure.html', 'evidence-vault.html'];
function file(name) { return path.join(root, name); }
function exists(name) { return fs.existsSync(file(name)); }
function read(name) { return exists(name) ? fs.readFileSync(file(name), 'utf8') : ''; }

if (!exists('scripts/build-free-ask-matrix-search.js')) issues.push('missing scripts/build-free-ask-matrix-search.js');
else {
  const rebuild = spawnSync(process.execPath, [file('scripts/build-free-ask-matrix-search.js')], { cwd: root, encoding: 'utf8', stdio: 'pipe' });
  if (rebuild.status !== 0) issues.push(`Search V2 rebuild failed: ${rebuild.stderr || rebuild.stdout}`);
}

for (const name of ['search.js','search.html','search-index.json']) if (!exists(name)) issues.push(`missing ${name}`);
const searchJs = read('search.js');
for (const marker of required) if (!searchJs.includes(marker)) issues.push(`search.js missing ${marker}`);

let index = [];
try { index = JSON.parse(read('search-index.json')); } catch { issues.push('search-index.json invalid JSON'); }
for (const route of ['control-structure.html','evidence-vault.html','daily-brain-brief.html','system-fusion-core.html','power-entities.html','data/system-fusion-core.json','data/entities.json']) {
  if (!Array.isArray(index) || !index.some(item => item.url === route)) issues.push(`search-index.json missing ${route}`);
}

if (issues.length) {
  console.error('SEARCH V2 FINAL GUARD FAILED');
  for (const issue of issues) console.error(`- ${issue}`);
  process.exit(1);
}
console.log('SEARCH V2 FINAL GUARD PASSED');
console.log('Search V2 was rebuilt last and validated after all Phase 15 routes.');
