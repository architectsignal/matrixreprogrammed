Add the Phase 15 runner to the end of the `build` script.

Find the end of the current build command:

```json
... && node scripts/site-function-harmony-test.js"
```

Replace it with:

```json
... && node scripts/site-function-harmony-test.js && node scripts/phase15-run-all.js"
```

Optional useful shortcuts:

```json
"phase15": "node scripts/phase15-run-all.js",
"phase15:entities": "node scripts/build-public-record-entities.js && node scripts/public-record-entities-test.js",
"phase15:fusion": "node scripts/build-system-fusion-core.js && node scripts/system-fusion-core-test.js",
"phase15:search-final": "node scripts/build-search-v2-final-guard.js"
```
