const fs = require('fs');
const path = require('path');

const root = process.cwd();
const dataDir = path.join(root, 'data');
const downloadsDir = path.join(root, 'downloads');
const jsDir = path.join(root, 'js');
fs.mkdirSync(dataDir, { recursive: true });
fs.mkdirSync(downloadsDir, { recursive: true });
fs.mkdirSync(jsDir, { recursive: true });

const updated = new Date().toISOString();
const version = 'PHASE-15-PUBLIC-RECORD-ENTITY-ENGINE';

const file = name => path.join(root, name);
const exists = name => fs.existsSync(file(name));
const read = name => exists(name) ? fs.readFileSync(file(name), 'utf8') : '';
const write = (name, value) => fs.writeFileSync(file(name), value);
function readJson(name, fallback) { try { const text = read(name); return text ? JSON.parse(text) : fallback; } catch { return fallback; } }
function esc(value = '') { return String(value ?? '').replace(/[&<>"']/g, c => ({ '&':'&amp;', '<':'&lt;', '>':'&gt;', '"':'&quot;', "'":'&#39;' }[c])); }
function clean(value = '') { return String(value ?? '').replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ').trim(); }
function slug(value = 'entity') { return clean(value).toLowerCase().replace(/&/g, ' and ').replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '').slice(0, 90) || 'entity'; }
function arr(value) { return Array.isArray(value) ? value.filter(Boolean) : (value ? [value] : []); }
function uniq(items) { return [...new Set(arr(items).map(clean).filter(Boolean))]; }

const evidenceLadder = [
  ['proven', 'Proven / convicted'],
  ['charged', 'Charged / sued'],
  ['documented', 'Documented association'],
  ['conflict', 'Public-record conflict'],
  ['allegation', 'Credible allegation'],
  ['hypothesis', 'Hypothesis'],
  ['unsupported', 'Unsupported claim']
].map(([id, label]) => ({ id, label }));

const layerTerms = {
  money: ['money','finance','payment','bank','reserve','gold','debt','capital','cbdc'],
  identity: ['identity','biometric','wallet','access','login','border','travel','health'],
  information: ['media','search','platform','narrative','cloud','ads','transparency','information'],
  security: ['security','defense','war','intelligence','cyber','surveillance','space'],
  infrastructure: ['energy','logistics','data center','chips','compute','rail','commerce','supply'],
  institutions: ['foundation','policy','board','grant','lobby','forum','agency','contract'],
  disclosure: ['filing','court','record','redaction','withheld','audit','archive'],
  review: ['claim','source chain','metadata','counter-source','hypothesis']
};

function inferLayers(values) {
  const hay = arr(values).flatMap(v => Array.isArray(v) ? v : [v]).join(' ').toLowerCase();
  const out = Object.entries(layerTerms).filter(([, terms]) => terms.some(t => hay.includes(t))).map(([id]) => id);
  return out.length ? out : ['institutions'];
}

function typeFromName(name) {
  const n = String(name || '').toLowerCase();
  if (/bank|reserve|treasury/.test(n)) return 'bank';
  if (/foundation|trust|fund/.test(n)) return 'foundation';
  if (/agency|department|commission|court|regulator/.test(n)) return 'agency';
  if (/media|news|platform|search/.test(n)) return 'media';
  if (/contract|security|defense/.test(n)) return 'contractor';
  return 'company';
}

const controlCore = readJson('data/control-structure-core.json', { layers: [] });
const billionaireCore = readJson('data/billionaire-watch-core.json', { watchlist: [] });
const liveIntel = readJson('downloads/live-intel-latest.json', readJson('data/live-intel.json', { items: [] }));
const clocks = readJson('data/global-risk-clocks.json', { clocks: [] });

const entityMap = new Map();
const linkMap = new Map();

function putEntity(entity) {
  const id = entity.id || slug(entity.name);
  const prior = entityMap.get(id) || {};
  const merged = {
    id,
    name: entity.name || prior.name || id,
    type: entity.type || prior.type || 'entity',
    control_layers: uniq([...(prior.control_layers || []), ...(entity.control_layers || [])]),
    roles: uniq([...(prior.roles || []), ...(entity.roles || [])]),
    known_records: uniq([...(prior.known_records || []), ...(entity.known_records || [])]),
    missing_records: uniq([...(prior.missing_records || []), ...(entity.missing_records || [])]),
    evidence_grade: entity.evidence_grade || prior.evidence_grade || 'documented',
    watch_triggers: uniq([...(prior.watch_triggers || []), ...(entity.watch_triggers || [])]),
    routes: uniq([...(prior.routes || []), ...(entity.routes || [])]),
    summary: entity.summary || prior.summary || 'Public-record entity route.',
    last_updated: updated.slice(0, 10)
  };
  if (!merged.control_layers.length) merged.control_layers = inferLayers([merged.name, merged.roles, merged.known_records, merged.missing_records]);
  entityMap.set(id, merged);
  return merged;
}

function putLink(link) {
  if (!link.from || !link.to) return;
  const id = `${link.from}__${link.relationship_type || 'linked'}__${link.to}`;
  const prior = linkMap.get(id) || {};
  linkMap.set(id, {
    id,
    from: link.from,
    to: link.to,
    relationship_type: link.relationship_type || prior.relationship_type || 'public-record route',
    evidence_grade: link.evidence_grade || prior.evidence_grade || 'documented',
    strength: Math.max(Number(prior.strength || 0), Number(link.strength || 1)),
    sources: uniq([...(prior.sources || []), ...(link.sources || [])]),
    notes: link.notes || prior.notes || 'Relationship is limited to public-record context.',
    updated: updated.slice(0, 10)
  });
}

for (const layer of arr(controlCore.layers)) {
  putEntity({
    id: `layer-${slug(layer.name || layer.id)}`,
    name: layer.name || layer.id,
    type: 'control_layer',
    control_layers: inferLayers([layer.name, layer.question, layer.watch]),
    roles: ['Control-structure layer'],
    known_records: arr(layer.routes).map(x => `Route: ${x}`),
    missing_records: arr(layer.watch),
    evidence_grade: 'hypothesis',
    watch_triggers: arr(layer.watch),
    routes: arr(layer.routes),
    summary: layer.question || 'Control layer route.'
  });
}

for (const subject of arr(billionaireCore.watchlist)) {
  const subjectId = `person-${slug(subject.name)}`;
  const layers = inferLayers([subject.layers, subject.track, subject.recordsNeeded, subject.convergenceLinks]);
  putEntity({
    id: subjectId,
    name: subject.name,
    type: 'person',
    control_layers: layers,
    roles: ['Billionaire Watch subject', ...arr(subject.wealthSource).map(x => `Public wealth-source route: ${x}`)],
    known_records: arr(subject.track),
    missing_records: arr(subject.recordsNeeded),
    evidence_grade: 'documented',
    watch_triggers: uniq([...(subject.track || []), ...(subject.recordsNeeded || [])]),
    routes: ['billionaire-watch.html','power-atlas.html','control-structure.html'],
    summary: 'Tracked as a public-record wealth, institution and infrastructure route. This does not claim private intent.'
  });
  for (const company of arr(subject.wealthSource)) {
    const companyId = `${typeFromName(company)}-${slug(company)}`;
    putEntity({
      id: companyId,
      name: company,
      type: typeFromName(company),
      control_layers: layers,
      roles: ['Named public wealth-source / institution route'],
      known_records: arr(subject.track),
      missing_records: arr(subject.recordsNeeded),
      evidence_grade: 'documented',
      watch_triggers: arr(subject.track),
      routes: ['billionaire-watch.html','evidence-vault.html'],
      summary: 'Tracked as a public-record organization route connected to filings, policy, contracts or dependency layers where records exist.'
    });
    putLink({
      from: subjectId,
      to: companyId,
      relationship_type: 'wealth-source / public-role route',
      evidence_grade: 'documented',
      strength: 4,
      sources: arr(subject.track)
    });
  }
}

for (const item of arr(liveIntel.items).slice(0, 80)) {
  const title = clean(item.title || item.summary || 'Live intel item');
  putEntity({
    id: `intel-${slug(title)}`,
    name: title,
    type: 'intel_drop',
    control_layers: inferLayers([item.lane, item.laneTitle, item.summary, item.whyItMatters]),
    roles: ['Live intel drop'],
    known_records: [item.url, item.evidenceRoute].filter(Boolean),
    missing_records: [item.nextAction].filter(Boolean),
    evidence_grade: item.evidenceLevel ? 'documented' : 'hypothesis',
    watch_triggers: [item.whyItMatters, item.nextAction].filter(Boolean),
    routes: [item.url, item.evidenceRoute, 'live-intel.html'].filter(Boolean),
    summary: item.summary || item.whyItMatters || 'Live intel update.'
  });
}

const categorySeeds = [
  ['central-banks','Central banks','bank','money reserve gold custody audit'],
  ['payment-networks','Payment networks','company','payment access compliance identity'],
  ['identity-vendors','Identity vendors','contractor','identity biometric wallet access procurement'],
  ['cloud-ai-infrastructure','Cloud and AI infrastructure providers','company','cloud AI compute public contracts security'],
  ['foundations-grant-networks','Foundations and grant networks','foundation','foundation grants policy influence filings'],
  ['public-record-custodians','Public-record custodians','agency','court archive redaction withheld records'],
  ['media-platform-gatekeepers','Media and platform gatekeepers','media','media search platform speech access transparency'],
  ['security-contractors','Security contractors','contractor','security emergency procurement oversight']
];

for (const [id, name, type, text] of categorySeeds) {
  putEntity({
    id,
    name,
    type,
    control_layers: inferLayers(text),
    roles: ['Category tracker until named records are attached'],
    known_records: ['Needs exact public record route'],
    missing_records: ['named institution', 'contract or filing', 'source link', 'date', 'jurisdiction'],
    evidence_grade: 'hypothesis',
    watch_triggers: ['new filing', 'contract award', 'court record', 'redaction log', 'policy mandate'],
    routes: ['control-structure.html','evidence-vault.html','record-intake-queue.html'],
    summary: 'Category tracker used to route future public records into named entity files.'
  });
}

const entities = [...entityMap.values()].sort((a, b) => (b.control_layers.length + b.known_records.length) - (a.control_layers.length + a.known_records.length) || a.name.localeCompare(b.name));
const links = [...linkMap.values()].sort((a, b) => Number(b.strength || 0) - Number(a.strength || 0));
const layerCounts = {};
for (const entity of entities) for (const layer of entity.control_layers || []) layerCounts[layer] = (layerCounts[layer] || 0) + 1;
const missingRecordQueue = entities.flatMap(e => arr(e.missing_records).map(record => ({ entityId: e.id, entityName: e.name, record, evidence_grade: e.evidence_grade, route: (e.routes || [])[0] || 'evidence-vault.html' }))).slice(0, 160);
const highLeverage = entities.filter(e => e.control_layers.length >= 3 || e.known_records.length >= 4).slice(0, 30);

write('data/evidence-ladder.json', JSON.stringify({ updated, evidenceLadder }, null, 2));
write('data/entities.json', JSON.stringify({ updated, version, boundary: 'Public-record entity tracking separates records, association, allegation, hypothesis and unsupported claim.', layerCounts, entities }, null, 2));
write('data/entity-links.json', JSON.stringify({ updated, version, scoring: { 1:'weak public association', 2:'repeated association', 3:'formal documented relationship', 4:'money / contract / board / ownership / major public-role route', 5:'central dependency route' }, links }, null, 2));
write('data/entity-updates.json', JSON.stringify({ updated, version, highLeverage, missingRecordQueue, clockInputs: arr(clocks.clocks).map(c => ({ slug: c.slug, title: c.title, score: c.score, nextRoute: c.nextRoute, latestDrops: arr(c.latestDrops).slice(0, 5) })) }, null, 2));

write('downloads/public-record-entities.md', [
  '# Public Record Entities',
  '',
  `Updated: ${updated}`,
  '',
  `Entities: ${entities.length}`,
  `Links: ${links.length}`,
  '',
  '## High Leverage',
  ...highLeverage.map(e => `- ${e.name} — ${e.type} — ${e.control_layers.join(', ')}`),
  '',
  '## Missing Records',
  ...missingRecordQueue.slice(0, 60).map(x => `- ${x.entityName}: ${x.record}`),
  ''
].join('\n'));

function card(e) {
  return `<article class="card redline"><span class="label">${esc(e.type)} · ${esc(e.evidence_grade)}</span><h3>${esc(e.name)}</h3><p>${esc(e.summary)}</p><p>${arr(e.control_layers).map(x => `<span class="pill">${esc(x)}</span>`).join(' ')}</p><p><strong>Known records:</strong> ${esc(arr(e.known_records).slice(0, 3).join(' / ') || 'Needs intake.')}</p><p><strong>Missing records:</strong> ${esc(arr(e.missing_records).slice(0, 3).join(' / ') || 'None listed.')}</p><div class="cta-row small"><a class="btn" href="entity.html?id=${encodeURIComponent(e.id)}">Open Entity</a><a class="btn alt" href="evidence-vault.html">Evidence</a></div></article>`;
}
const nav = `<header class="wrap topbar"><a class="brand" href="index.html"><img src="sigil.png" alt="Matrix Reprogrammed sigil"/> MATRIX REPROGRAMMED</a><nav class="nav"><a href="control-structure.html">Control Map</a><a href="system-fusion-core.html">Fusion Core</a><a href="daily-brain-brief.html">Daily Brain</a><a href="evidence-vault.html">Evidence</a><a href="search.html">Search</a></nav></header>`;

write('power-entities.html', `<!DOCTYPE html><html lang="en"><head><meta charset="UTF-8"/><meta name="viewport" content="width=device-width, initial-scale=1.0"/><title>Power Entity Engine | Matrix Reprogrammed</title><meta name="description" content="Evidence-graded public-record entity tracking for people, institutions, companies, banks, foundations, agencies, contractors, media groups and policy bodies."/><link rel="stylesheet" href="styles.css"/><link rel="stylesheet" href="fixes.css"/></head><body><canvas id="matrix"></canvas><div class="signal-face"></div><div class="veil"></div><div class="page">${nav}<main><section class="hero wrap"><div class="eyebrow">${version}</div><h1>POWER ENTITY ENGINE.</h1><p class="lead">People, institutions, companies, banks, foundations, agencies, contractors, media groups, intel drops and control layers now feed one evidence-graded map.</p><div class="cta-row"><a class="btn" href="data/entities.json">Entities JSON</a><a class="btn alt" href="data/entity-links.json">Relationships</a><a class="btn alt" href="data/entity-updates.json">Update Feed</a><a class="btn alt" href="system-fusion-core.html">Fusion Core</a></div></section><section class="section wrap split"><div class="terminal">POWER ENTITY ENGINE\n&gt; Updated: ${esc(updated)}\n&gt; Entities: ${entities.length}\n&gt; Relationships: ${links.length}\n&gt; Missing-record prompts: ${missingRecordQueue.length}\n&gt; Evidence ladder: active</div><aside class="card redline"><h2>Boundary</h2><p>Records before claims. Every entity file separates proven records, public associations, conflicts, allegations, hypotheses and unsupported claims.</p></aside></section><section class="section wrap"><h2>Search Entities</h2><input id="entity-search" type="search" placeholder="Search person, institution, company, record, route, layer..."/><p class="filter-count" id="entity-count">Showing ${entities.length} tracked entities.</p><div class="grid" id="entity-results">${entities.slice(0, 60).map(card).join('')}</div></section></main><footer class="footer wrap"><p><strong>MATRIX REPROGRAMMED</strong> — the power map is a record map.</p></footer></div><script src="matrix.js"></script><script src="living-pulse.js"></script><script src="js/entity-engine.js"></script></body></html>`);

write('entity.html', `<!DOCTYPE html><html lang="en"><head><meta charset="UTF-8"/><meta name="viewport" content="width=device-width, initial-scale=1.0"/><title>Entity File | Matrix Reprogrammed</title><meta name="description" content="Evidence-graded Matrix Reprogrammed public-record entity file."/><link rel="stylesheet" href="styles.css"/><link rel="stylesheet" href="fixes.css"/></head><body><canvas id="matrix"></canvas><div class="signal-face"></div><div class="veil"></div><div class="page">${nav}<main><section class="hero wrap"><div class="eyebrow">Evidence-Graded Entity File</div><h1 id="entity-title">ENTITY FILE.</h1><p class="lead" id="entity-summary">Loading public-record entity file...</p><div class="cta-row"><a class="btn" href="power-entities.html">All Entities</a><a class="btn alt" href="data/entities.json">Entities JSON</a><a class="btn alt" href="data/entity-links.json">Relationships</a></div></section><section class="section wrap" id="entity-file"><article class="card redline"><h2>Loading...</h2></article></section></main><footer class="footer wrap"><p><strong>MATRIX REPROGRAMMED</strong> — record route first, claim second.</p></footer></div><script src="matrix.js"></script><script src="js/entity-engine.js"></script></body></html>`);

write('js/entity-engine.js', `(function(){function esc(s){return String(s||'').replace(/[&<>"']/g,function(c){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c];});}function arr(x){return Array.isArray(x)?x.filter(Boolean):(x?[x]:[]);}function url(id){return 'entity.html?id='+encodeURIComponent(id);}function card(e){return '<article class="card redline"><span class="label">'+esc(e.type)+' · '+esc(e.evidence_grade)+'</span><h3>'+esc(e.name)+'</h3><p>'+esc(e.summary||'Public-record route.')+'</p><p>'+arr(e.control_layers).map(function(x){return '<span class="pill">'+esc(x)+'</span>';}).join(' ')+'</p><a class="btn" href="'+url(e.id)+'">Open Entity</a></article>';}function list(t,items){items=arr(items);return '<article class="card"><span class="label">'+esc(t)+'</span>'+(items.length?'<ul>'+items.map(function(x){return '<li>'+esc(x)+'</li>';}).join('')+'</ul>':'<p>None listed.</p>')+'</article>';}Promise.all([fetch('data/entities.json',{cache:'no-store'}).then(function(r){return r.json();}),fetch('data/entity-links.json',{cache:'no-store'}).then(function(r){return r.json();}).catch(function(){return {links:[]};})]).then(function(pair){var data=pair[0], links=pair[1];var input=document.getElementById('entity-search'),results=document.getElementById('entity-results'),count=document.getElementById('entity-count');var entities=arr(data.entities);if(input&&results){function run(){var q=String(input.value||'').toLowerCase();var out=entities.filter(function(e){return !q||[e.name,e.type,arr(e.control_layers).join(' '),arr(e.roles).join(' '),arr(e.known_records).join(' '),arr(e.missing_records).join(' ')].join(' ').toLowerCase().includes(q);}).slice(0,96);results.innerHTML=out.map(card).join('')||'<article class="card redline"><h3>No entity match</h3></article>';if(count)count.textContent='Showing '+out.length+' of '+entities.length+' tracked entities.';}input.addEventListener('input',run);run();}var holder=document.getElementById('entity-file');if(holder){var id=new URLSearchParams(location.search).get('id')||'';var e=entities.find(function(x){return x.id===id;})||entities[0];if(!e)return;var title=document.getElementById('entity-title'),summary=document.getElementById('entity-summary');if(title)title.textContent=e.name.toUpperCase();if(summary)summary.textContent=e.summary||'Public-record entity route.';var rel=arr(links.links).filter(function(l){return l.from===e.id||l.to===e.id;});holder.innerHTML='<div class="grid"><article class="card redline"><span class="label">'+esc(e.type)+' · '+esc(e.evidence_grade)+'</span><h2>'+esc(e.name)+'</h2><p>'+arr(e.control_layers).map(function(x){return '<span class="pill">'+esc(x)+'</span>';}).join(' ')+'</p><p><strong>Boundary:</strong> This file maps records and missing records. It does not assert wrongdoing without evidence-grade support.</p></article>'+list('Roles',e.roles)+list('Known records',e.known_records)+list('Missing records',e.missing_records)+list('Watch triggers',e.watch_triggers)+'</div><section class="section"><h2>Relationship Routes</h2><div class="grid">'+(rel.map(function(l){var other=l.from===e.id?l.to:l.from;var oe=entities.find(function(x){return x.id===other;});return '<article class="card redline"><span class="label">Strength '+esc(l.strength)+' · '+esc(l.evidence_grade)+'</span><h3>'+esc(l.relationship_type)+'</h3><p>'+esc(e.name)+' ↔ '+esc(oe?oe.name:other)+'</p><p>'+esc(l.notes||'Public-record relationship route.')+'</p><a class="btn alt" href="'+url(other)+'">Open Linked Entity</a></article>';}).join('')||'<article class="card"><h3>No relationship routes loaded yet</h3></article>')+'</div></section>';}}).catch(function(err){var holder=document.getElementById('entity-results')||document.getElementById('entity-file');if(holder)holder.innerHTML='<article class="card redline"><h3>Entity engine failed</h3><p>'+esc(err.message||err)+'</p></article>';});})();`);

console.log(`Public record entity engine built: ${entities.length} entities, ${links.length} links, ${missingRecordQueue.length} missing-record prompts.`);
