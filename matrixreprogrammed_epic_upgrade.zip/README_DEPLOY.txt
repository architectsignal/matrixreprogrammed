MATRIX REPROGRAMMED EPIC UPGRADE

What this includes:
- Keeps the Matrix rain effect on every page
- Keeps sigil.png and face_big.png image references so your current assets still work
- Adds book archive page with the ASINs you provided
- Adds D.O.G The Architect page
- Adds Intelligence Dossiers page
- Adds Crime Dossiers page
- Adds Masonic & Esoteric page
- Adds Black File email capture page using Netlify Forms markup
- Adds Rumble pathway on Transmissions page
- Adds SEO titles/descriptions

How to use:
1. Upload these files over the existing site files in GitHub or Netlify.
2. Keep your existing image files: sigil.png, face_big.png, face.png.
3. Replace the Rumble search link with your exact Rumble channel URL once confirmed.
4. Replace generic ASIN card titles with final Amazon book titles when ready.

Important:
The GitHub connector returned a 403 write error, so ChatGPT could not commit directly in this run.
To enable automatic updates, the GitHub app/integration needs contents write access to this repo.
