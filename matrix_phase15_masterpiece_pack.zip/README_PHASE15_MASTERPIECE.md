# Matrix Reprogrammed — Phase 15 Masterpiece Pack

This pack adds the next architecture layer:

- **Public Record Entity Engine**: people, institutions, companies, banks, foundations, agencies, contractors, media groups, control layers and intel drops become evidence-graded entity files.
- **Relationship scoring**: public-record relationships are scored from weak association to central dependency route.
- **System Fusion Core**: clocks, live intel, forum exports, probability signals, outcome briefings, public-record entities and the Daily Brain feed one shared nervous system.
- **Clock signal feed**: clocks receive structured signal inputs from the fusion core.
- **Final Search V2 guard**: Search V2 rebuilds at the end and fails the build if any later script overwrites it.
- **Tests**: entity engine, fusion core and Search V2 final guard.

## Files to add

Copy these files into your repo:

```text
scripts/build-public-record-entities.js
scripts/build-system-fusion-core.js
scripts/build-search-v2-final-guard.js
scripts/public-record-entities-test.js
scripts/system-fusion-core-test.js
scripts/phase15-run-all.js
```

## Package build patch

Add this near the end of your `package.json` build command:

```bash
&& node scripts/phase15-run-all.js
```

Best position: after the current `node scripts/site-function-harmony-test.js`.

## What it generates

```text
power-entities.html
entity.html
system-fusion-core.html
js/entity-engine.js
data/entities.json
data/entity-links.json
data/entity-updates.json
data/evidence-ladder.json
data/system-fusion-core.json
data/matrix-nervous-system.json
data/clock-signal-feed.json
downloads/public-record-entities.md
downloads/system-fusion-core.md
```

## Future-proofing rule

The final build step must always be:

```bash
node scripts/build-search-v2-final-guard.js
```

This guard rebuilds Search V2 after all other build scripts and checks the final `search.js` contains:

```text
SEARCH V2
/search-index.json
layerMap
control-structure.html
evidence-vault.html
```

That prevents the old overwrite problem from returning.

## Safety / evidence rule

This system does not assert wrongdoing. It maps:

```text
records
routes
public associations
missing records
watch triggers
evidence grades
relationship strength
```

Every entity file must preserve the evidence boundary:

```text
record route first
claim second
unsupported claim quarantined
```
