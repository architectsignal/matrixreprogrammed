const fs = require('fs');
const path = require('path');
const root = process.cwd();
const issues = [];
function file(name) { return path.join(root, name); }
function exists(name) { return fs.existsSync(file(name)); }
function read(name) { return fs.readFileSync(file(name), 'utf8'); }
function needFile(name) { if (!exists(name)) issues.push(`missing ${name}`); }
function needText(name, text) { if (exists(name) && !read(name).includes(text)) issues.push(`${name} missing ${text}`); }

for (const name of ['data/entities.json','data/entity-links.json','data/entity-updates.json','data/evidence-ladder.json','power-entities.html','entity.html','js/entity-engine.js']) needFile(name);
needText('power-entities.html', 'POWER ENTITY ENGINE.');
needText('power-entities.html', 'Evidence');
needText('entity.html', 'Evidence-Graded Entity File');
needText('js/entity-engine.js', 'data/entities.json');

if (exists('data/entities.json')) {
  const data = JSON.parse(read('data/entities.json'));
  if (!Array.isArray(data.entities) || data.entities.length < 10) issues.push('entity engine should generate at least 10 entities');
  if (!data.entities.some(e => e.type === 'person')) issues.push('entity engine should include public-record person routes when source data exists');
  if (!data.entities.some(e => Array.isArray(e.missing_records) && e.missing_records.length)) issues.push('entities should carry missing-record prompts');
}
if (exists('data/entity-links.json')) {
  const links = JSON.parse(read('data/entity-links.json'));
  if (!Array.isArray(links.links)) issues.push('entity-links.json must contain links array');
}
if (issues.length) {
  console.error('PUBLIC RECORD ENTITY ENGINE TEST FAILED');
  for (const issue of issues) console.error(`- ${issue}`);
  process.exit(1);
}
console.log('PUBLIC RECORD ENTITY ENGINE TEST PASSED');
